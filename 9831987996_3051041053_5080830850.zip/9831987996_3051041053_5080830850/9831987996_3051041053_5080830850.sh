# Basic
javac Basic_9831987996_3051041053_5080830850.java
java Basic_9831987996_3051041053_5080830850 input.txt  #(and this will write to the output.txt)


# Memory Efficient
javac Efficient_9831987996_3051041053_5080830850.java
java Efficient_9831987996_3051041053_5080830850 input.txt  #(and this will write to the output.txt)
